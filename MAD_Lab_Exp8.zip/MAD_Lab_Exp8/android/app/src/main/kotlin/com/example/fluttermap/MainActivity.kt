package com.example.fluttermap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
